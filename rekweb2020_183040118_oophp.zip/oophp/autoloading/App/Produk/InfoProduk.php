<?php 

interface InfoProduk {
	public function getInfoProduk();
}