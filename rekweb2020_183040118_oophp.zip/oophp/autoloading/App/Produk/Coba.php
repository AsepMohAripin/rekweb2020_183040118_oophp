<?php 

class Coba {
	public Function __construct()
	{
		echo "Ini adalah kelas Coba";
	}
}